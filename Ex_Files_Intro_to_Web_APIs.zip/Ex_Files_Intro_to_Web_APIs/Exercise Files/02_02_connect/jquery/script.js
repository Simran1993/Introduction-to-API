$.get ('https://hplussport.com/api/products',function(response) {
		console.log(response)
	}
)